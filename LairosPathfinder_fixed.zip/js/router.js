const routes = {};
export function route(path, component){ routes[path] = component; }
export function startRouter(){
  const app = document.getElementById("app");
  async function render(){
    const hash = location.hash || "#/dashboard";

    // Let normal in-page anchors like #media work without triggering SPA routing
    if (!hash.startsWith("#/")) return;

    const key = hash.split("?")[0];
    const view = routes[key] || routes["#/dashboard"];
    app.replaceChildren(await view());
  }
  window.addEventListener("hashchange", render);
  render();
}

export { default as Dashboard } from './dashboard.js';
export { default as Planner } from './planner.js';
export { default as GPA } from './gpa.js';
export { default as Research } from './research.js';
export { default as Health } from './health.js';
export { default as Goals } from './goals.js';
export { default as AI } from './ai.js';
export { default as Settings } from './settings.js';
